package com.example.eventtrackingapp;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Activity for creating a new Event.
 * Presents UI for title, description, date, and time,
 * saves the event to the database, and schedules an SMS reminder.
 */
public class AddEventActivity extends AppCompatActivity {

    // Name of the SharedPreferences file
    private static final String PREFS_NAME = "AppPrefs";
    // Key for storing notification offset (in hours) in preferences
    private static final String PREF_NOTIFICATION_OFFSET = "notification_offset_hours";

    // UI components
    private EditText editTextTitle, editTextDescription;
    private Button buttonDate, buttonTime, buttonAdd;

    // Track the user’s chosen date and time
    private String selectedDate = "", selectedTime = "";
    // ID of the logged-in user, passed via Intent
    private int userId;

    /**
     * Called when the activity is first created.
     * Initializes views, retrieves user ID, and sets up button listeners.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Retrieve the user ID from the launching Intent
        userId = getIntent().getIntExtra("user_id", -1);

        // Find UI elements
        editTextTitle = findViewById(R.id.editTextEventTitle);
        editTextDescription = findViewById(R.id.editTextEventDescription);
        buttonDate = findViewById(R.id.buttonSelectDate);
        buttonTime = findViewById(R.id.buttonSelectTime);
        buttonAdd = findViewById(R.id.buttonAddEvent);

        // Show date/time pickers when buttons are clicked
        buttonDate.setOnClickListener(v -> showDatePicker());
        buttonTime.setOnClickListener(v -> showTimePicker());

        // Handle Add Event button click
        buttonAdd.setOnClickListener(v -> {
            String title = editTextTitle.getText().toString().trim();
            String description = editTextDescription.getText().toString().trim();
            String dateTime = selectedDate + " " + selectedTime;

            // Validate required fields
            if (title.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
                Toast.makeText(this, "Please fill in all required fields.", Toast.LENGTH_LONG).show();
                return;
            }

            // Create new Event object and save it
            Event newEvent = new Event(title, description, dateTime);
            newEvent.setUserId(userId);

            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            long rowId = db.eventDao().insertEvent(newEvent);
            newEvent.setId((int) rowId);

            // Schedule SMS reminder based on preferences
            scheduleSms(newEvent);

            Toast.makeText(this, "Event added!", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        });
    }

    /**
     * Displays a DatePicker dialog for the user to select a date.
     * Updates selectedDate and the button label.
     */
    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        new DatePickerDialog(this,
                (view, year, month, day) -> {
                    // Format month/day/year
                    selectedDate = (month + 1) + "/" + day + "/" + year;
                    buttonDate.setText(selectedDate);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    /**
     * Displays a TimePicker dialog for the user to select a time.
     * Updates selectedTime and the button label.
     */
    private void showTimePicker() {
        final Calendar c = Calendar.getInstance();
        new TimePickerDialog(this,
                (view, hourOfDay, minute) -> {
                    // Format hours and minutes with leading zeros
                    selectedTime = String.format("%02d:%02d", hourOfDay, minute);
                    buttonTime.setText(selectedTime);
                },
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                true
        ).show();
    }

    /**
     * Schedules an SMS reminder for the given event.
     * Reads offset from SharedPreferences and sets an AlarmManager.
     */
    private void scheduleSms(Event event) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        // Default offset is 24 hours before the event
        int offset = prefs.getInt(PREF_NOTIFICATION_OFFSET, 24);
        try {
            // Parse the event’s date/time string
            SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy HH:mm", Locale.US);
            Date eventDate = sdf.parse(event.getDateTime());
            long eventTimeMs = eventDate.getTime();
            long now = System.currentTimeMillis();
            if (eventTimeMs <= now) return;  // Skip past events

            // Calculate trigger time in milliseconds
            long triggerAt = eventTimeMs - offset * 3600000L;
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            // Prepare the broadcast Intent for SmsAlarmReceiver
            Intent intent = new Intent(this, SmsAlarmReceiver.class);
            intent.putExtra("event_id", event.getId());
            PendingIntent pi = PendingIntent.getBroadcast(
                    this,
                    event.getId(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Schedule the alarm
            am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}