package com.example.eventtrackingapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * RecyclerView.Adapter for displaying a list of Event items.
 * Handles expansion/collapse, editing, and deletion in the UI.
 */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private final Context context;
    private List<Event> eventList;        // Current list of events
    private final AppDatabase db;         // Database instance for operations
    private float uniformTextSizePx = 0f; // Shared text size for buttons

    public EventAdapter(Context context, List<Event> eventList) {
        this.context = context;
        this.eventList = eventList;
        this.db = AppDatabase.getInstance(context);
    }

    /**
     * Allows external setting of uniform text size (in pixels).
     */
    public void setUniformTextSizePx(float sizePx) {
        this.uniformTextSizePx = sizePx;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout
        View view = LayoutInflater.from(context)
                .inflate(R.layout.event_item, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        // Populate UI elements
        holder.textTitle.setText(event.getTitle());
        holder.textDate.setText(formatDateTime(event.getDateTime()));
        holder.textDescription.setText(event.getDescription());

        boolean isExpanded = event.isExpanded();
        // Show/hide details based on expand state
        holder.textDescription.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        holder.buttonEdit.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        holder.buttonDelete.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        holder.textCaret.setText(isExpanded ? "˄" : "⌄");

        // Toggle expand/collapse when the item is clicked
        holder.itemView.setOnClickListener(v -> {
            event.setExpanded(!event.isExpanded());
            notifyItemChanged(position);
        });

        // Handle deletion with confirmation dialog
        holder.buttonDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Confirm Deletion")
                    .setMessage("Are you sure you want to delete this event?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        db.eventDao().deleteEvent(event);
                        eventList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, eventList.size());
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Launch EditEventActivity when Edit is clicked
        holder.buttonEdit.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditEventActivity.class);
            intent.putExtra("event_id", event.getId());
            intent.putExtra("event_title", event.getTitle());
            intent.putExtra("event_description", event.getDescription());
            intent.putExtra("event_datetime", event.getDateTime());
            context.startActivity(intent);
        });

        // Apply uniform text size to buttons if specified
        if (uniformTextSizePx > 0) {
            holder.buttonEdit.setTextSize(TypedValue.COMPLEX_UNIT_PX, uniformTextSizePx);
            holder.buttonDelete.setTextSize(TypedValue.COMPLEX_UNIT_PX, uniformTextSizePx);
        }

        // Center edit/delete buttons around the caret
        holder.containerButtons.post(() -> {
            float containerWidth = holder.containerButtons.getWidth();
            float caretCenterX = holder.textCaret.getX() + holder.textCaret.getWidth() / 2f;
            float editX = caretCenterX / 2f - holder.buttonEdit.getWidth() / 2f;
            float deleteX = (containerWidth + caretCenterX) / 2f - holder.buttonDelete.getWidth() / 2f;
            holder.buttonEdit.setX(editX);
            holder.buttonDelete.setX(deleteX);
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    /**
     * Replace the current list of events and refresh the UI.
     */
    public void setEvents(List<Event> newList) {
        this.eventList = newList;
        notifyDataSetChanged();
    }

    /**
     * ViewHolder class for event_item layout.
     */
    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle, textDate, textDescription, textCaret;
        Button buttonEdit, buttonDelete;
        FrameLayout containerButtons;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.textEventTitle);
            textDate = itemView.findViewById(R.id.textEventDate);
            textDescription = itemView.findViewById(R.id.textEventDescription);
            textCaret = itemView.findViewById(R.id.textCaret);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
            containerButtons = itemView.findViewById(R.id.containerButtons);
        }
    }

    /**
     * Converts a date string from 24-hour "M/d/yyyy HH:mm" to 12-hour "M/d/yyyy h:mm a" format.
     * @param original Original date/time string
     * @return Formatted date/time string
     */
    private String formatDateTime(String original) {
        try {
            SimpleDateFormat input = new SimpleDateFormat("M/d/yyyy HH:mm", Locale.US);
            SimpleDateFormat output = new SimpleDateFormat("M/d/yyyy h:mm a", Locale.US);
            Date date = input.parse(original);
            return output.format(date);
        } catch (ParseException e) {
            // If parsing fails, return the original
            return original;
        }
    }
}