package com.example.eventtrackingapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import java.util.List;

/**
 * BroadcastReceiver triggered by AlarmManager to send SMS reminders.
 */
public class SmsAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Extract the event ID from the Intent
        int eventId = intent.getIntExtra("event_id", -1);
        if (eventId == -1) return;

        AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());
        Event event = db.eventDao().getEventById(eventId);
        if (event == null) return;

        // Fetch all phone numbers for the event’s user
        int userId = event.getUserId();
        List<PhoneNumber> numbers = db.phoneNumberDao().getNumbersForUser(userId);

        SmsManager smsManager = SmsManager.getDefault();
        String message = "Reminder: " + event.getTitle() + " at " + event.getDateTime();
        // Send the reminder to each stored phone number
        for (PhoneNumber pn : numbers) {
            smsManager.sendTextMessage(pn.getNumber(), null, message, null, null);
        }
    }
}