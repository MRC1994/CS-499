package com.example.eventtrackingapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * Settings screen allowing the user to enable SMS,
 * set notification offset, and manage phone numbers.
 */
public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AppPrefs";
    private static final String PREF_NOTIFICATION_OFFSET = "notification_offset_hours";

    private int userId;
    private AppDatabase db;

    // UI elements
    private Button buttonEnableSms, buttonAddPhone;
    private EditText editTextPhone;
    private RecyclerView phoneRecycler;
    private PhoneNumberAdapter phoneAdapter;

    private LinearLayout layoutNotificationOffset;
    private TextView textNotificationOffsetSuffix;

    /**
     * Initializes UI, populates offset spinner, and sets up phone list.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        userId = getIntent().getIntExtra("user_id", -1);
        db = AppDatabase.getInstance(this);

        // Find views
        buttonEnableSms = findViewById(R.id.buttonEnableSms);
        editTextPhone   = findViewById(R.id.editTextPhone);
        buttonAddPhone  = findViewById(R.id.buttonAddPhone);
        phoneRecycler   = findViewById(R.id.recyclerViewPhoneNumbers);

        layoutNotificationOffset     = findViewById(R.id.layoutNotificationOffset);
        Spinner spinnerNotificationOffset = findViewById(R.id.spinnerNotificationOffset);
        textNotificationOffsetSuffix = findViewById(R.id.textNotificationOffsetSuffix);

        // Populate spinner with values 1–48
        List<String> hours = new ArrayList<>();
        for (int i = 1; i <= 48; i++) hours.add(String.valueOf(i));
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, hours);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerNotificationOffset.setAdapter(adapter);

        // Load saved offset and update suffix label
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int savedOffset = prefs.getInt(PREF_NOTIFICATION_OFFSET, 24);
        spinnerNotificationOffset.setSelection(savedOffset - 1);
        updateSuffix(savedOffset);

        // Save new offset when spinner changes
        spinnerNotificationOffset.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onNothingSelected(AdapterView<?> parent) {}

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                int sel = pos + 1;
                prefs.edit().putInt(PREF_NOTIFICATION_OFFSET, sel).apply();
                updateSuffix(sel);
            }
        });

        // Setup phone number list
        phoneAdapter = new PhoneNumberAdapter(this, new ArrayList<>());
        phoneRecycler.setLayoutManager(new LinearLayoutManager(this));
        phoneRecycler.setAdapter(phoneAdapter);

        // Enable SMS settings
        buttonEnableSms.setOnClickListener(v -> openAppSettings());
        // Add a new phone number
        buttonAddPhone.setOnClickListener(v -> {
            String number = editTextPhone.getText().toString().trim();
            if (number.isEmpty()) {
                Toast.makeText(this, "Enter a phone number first.", Toast.LENGTH_LONG).show();
                return;
            }
            db.phoneNumberDao().insertNumber(new PhoneNumber(number, userId));
            editTextPhone.setText("");
            Toast.makeText(this, "Phone number added!", Toast.LENGTH_SHORT).show();
            updatePhoneList();
        });

        refreshUi();
        updatePhoneList();
    }

    /**
     * Updates the suffix text based on hours (singular vs. plural).
     */
    private void updateSuffix(int hours) {
        if (hours == 1) {
            textNotificationOffsetSuffix.setText(R.string.hour_before_event);
        } else {
            textNotificationOffsetSuffix.setText(R.string.hours_before_event);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUi();
        updatePhoneList();
        // Reapply uniform text size if set
        if (TextSizeUtil.uniformTextSizePx > 0) {
            phoneAdapter.setUniformTextSizePx(TextSizeUtil.uniformTextSizePx);
            phoneAdapter.notifyDataSetChanged();
        }
    }

    /**
     * Show or hide UI sections depending on SMS permission state.
     */
    private void refreshUi() {
        boolean hasSms = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (hasSms) {
            buttonEnableSms.setVisibility(View.GONE);
            layoutNotificationOffset.setVisibility(View.VISIBLE);
            editTextPhone.setVisibility(View.VISIBLE);
            buttonAddPhone.setVisibility(View.VISIBLE);
            updatePhoneList();
        } else {
            buttonEnableSms.setVisibility(View.VISIBLE);
            layoutNotificationOffset.setVisibility(View.GONE);
            editTextPhone.setVisibility(View.GONE);
            buttonAddPhone.setVisibility(View.GONE);
            phoneRecycler.setVisibility(View.GONE);
        }
    }

    /**
     * Fetches and displays the current list of phone numbers for this user.
     */
    private void updatePhoneList() {
        List<PhoneNumber> list = db.phoneNumberDao().getNumbersForUser(userId);
        phoneRecycler.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
        phoneAdapter.setPhoneNumbers(list);
    }

    /**
     * Opens the system App Settings page for enabling permissions.
     */
    private void openAppSettings() {
        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }
}