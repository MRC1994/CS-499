package com.example.eventtrackingapp;

import android.app.AlertDialog;
import android.content.Context;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

/**
 * RecyclerView.Adapter for displaying and deleting phone numbers in Settings.
 */
public class PhoneNumberAdapter extends RecyclerView.Adapter<PhoneNumberAdapter.PhoneNumberViewHolder> {

    private final Context context;
    private List<PhoneNumber> phoneList;  // Current list of phone numbers
    private final AppDatabase db;         // Database instance
    private float uniformTextSizePx = 0f; // Shared text size

    public PhoneNumberAdapter(Context context, List<PhoneNumber> phoneList) {
        this.context = context;
        this.phoneList = phoneList;
        this.db = AppDatabase.getInstance(context);
    }

    /**
     * Allows external setting of a uniform text size (in pixels).
     */
    public void setUniformTextSizePx(float sizePx) {
        this.uniformTextSizePx = sizePx;
    }

    @NonNull
    @Override
    public PhoneNumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the phone number item layout
        View view = LayoutInflater.from(context).inflate(R.layout.phone_number_item, parent, false);
        return new PhoneNumberViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhoneNumberViewHolder holder, int position) {
        PhoneNumber phone = phoneList.get(position);
        holder.textNumber.setText(phone.getNumber());

        // Handle deletion click with confirmation
        holder.buttonDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Confirm Deletion")
                    .setMessage("Delete this phone number?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        db.phoneNumberDao().deleteNumber(phone);
                        phoneList.remove(position);
                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, phoneList.size());
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Apply uniform text size if provided
        if (uniformTextSizePx > 0) {
            holder.buttonDelete.setTextSize(TypedValue.COMPLEX_UNIT_PX, uniformTextSizePx);
        }
    }

    @Override
    public int getItemCount() {
        return phoneList.size();
    }

    /**
     * Replace the current list of phone numbers and refresh the UI.
     */
    public void setPhoneNumbers(List<PhoneNumber> newList) {
        this.phoneList = newList;
        notifyDataSetChanged();
    }

    /**
     * ViewHolder for phone_number_item layout.
     */
    static class PhoneNumberViewHolder extends RecyclerView.ViewHolder {
        TextView textNumber;
        Button buttonDelete;

        PhoneNumberViewHolder(@NonNull View itemView) {
            super(itemView);
            textNumber = itemView.findViewById(R.id.textPhoneNumber);
            buttonDelete = itemView.findViewById(R.id.buttonDeletePhone);
        }
    }
}