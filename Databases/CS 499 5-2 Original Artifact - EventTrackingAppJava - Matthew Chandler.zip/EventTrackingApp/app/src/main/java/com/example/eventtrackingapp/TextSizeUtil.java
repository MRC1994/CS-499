package com.example.eventtrackingapp;

public class TextSizeUtil {
    // Holds the uniform px size computed from the Add Event button
    public static float uniformTextSizePx = 0f;
}