package com.example.eventtrackingapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.room.Room;

/**
 * Launcher activity handling user login and account creation.
 * Requests SMS permission on first run.
 */
public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 101;
    private static final String PREFS_NAME = "AppPrefs";
    private static final String PREF_SMS_REQUESTED = "smsPermissionRequested";

    // UI fields
    private EditText editTextUsername, editTextPassword;
    private Button buttonLogin, buttonCreateAccount;

    // Local user database
    private UserDatabase userDatabase;

    /**
     * Called on activity creation. Initializes UI, permissions, and database.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check if SMS permission has been requested before
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean smsRequested = prefs.getBoolean(PREF_SMS_REQUESTED, false);

        if (!smsRequested) {
            // Request SEND_SMS permission if not already granted
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);
            }
            prefs.edit().putBoolean(PREF_SMS_REQUESTED, true).apply();
        }

        // Find UI elements
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Initialize Room database for users
        userDatabase = Room.databaseBuilder(
                getApplicationContext(),
                UserDatabase.class,
                "user_database"
        ).allowMainThreadQueries().build();

        // Disable buttons until both fields have text
        buttonLogin.setEnabled(false);
        buttonCreateAccount.setEnabled(false);

        // Watch both text fields for input
        TextWatcher fieldWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                boolean fieldsFilled = !editTextUsername.getText().toString().trim().isEmpty()
                        && !editTextPassword.getText().toString().trim().isEmpty();
                buttonLogin.setEnabled(fieldsFilled);
                buttonCreateAccount.setEnabled(fieldsFilled);
            }
        };
        editTextUsername.addTextChangedListener(fieldWatcher);
        editTextPassword.addTextChangedListener(fieldWatcher);

        // Create account flow
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            User existingUser = userDatabase.userDao().getUserByUsername(username);
            if (existingUser != null) {
                Toast.makeText(this, "Username already taken. Enter a different username.", Toast.LENGTH_LONG).show();
            } else {
                userDatabase.userDao().insertUser(new User(username, password));
                Toast.makeText(this, "Account created successfully! You may now log in!", Toast.LENGTH_LONG).show();
                editTextPassword.setText("");
            }
        });

        // Login flow
        buttonLogin.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString().trim();
            String password = editTextPassword.getText().toString().trim();

            User user = userDatabase.userDao().getUserByUsername(username);
            if (user != null && user.password.equals(password)) {
                // Successful login: open EventGridActivity
                Intent intent = new Intent(MainActivity.this, EventGridActivity.class);
                intent.putExtra("user_id", user.id);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Incorrect username or password.", Toast.LENGTH_LONG).show();
            }
        });
    }
}