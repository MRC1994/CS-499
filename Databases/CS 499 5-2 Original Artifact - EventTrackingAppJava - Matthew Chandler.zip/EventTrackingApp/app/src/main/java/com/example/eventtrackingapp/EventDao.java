package com.example.eventtrackingapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

/**
 * Data Access Object for Event entities.
 * Defines queries for CRUD operations.
 */
@Dao
public interface EventDao {

    /**
     * Retrieve all events, sorted by date/time ascending.
     */
    @Query("SELECT * FROM events ORDER BY dateTime ASC")
    List<Event> getAllEvents();

    /**
     * Retrieve events for a specific user, sorted by date/time ascending.
     * @param userId ID of the user
     */
    @Query("SELECT * FROM events WHERE userId = :userId ORDER BY dateTime ASC")
    List<Event> getEventsForUser(int userId);

    /**
     * Retrieve a single event by its ID.
     * @param eventId ID of the event
     */
    @Query("SELECT * FROM events WHERE id = :eventId LIMIT 1")
    Event getEventById(int eventId);

    /**
     * Insert a new event into the database.
     * @return new row ID
     */
    @Insert
    long insertEvent(Event event);

    /**
     * Delete an event from the database.
     */
    @Delete
    void deleteEvent(Event event);

    /**
     * Update an existing event’s fields.
     */
    @Update
    void updateEvent(Event event);
}