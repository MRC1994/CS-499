package com.example.eventtrackingapp;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

/**
 * Data Access Object for PhoneNumber entities.
 * Defines queries to retrieve, insert, and delete numbers.
 */
@Dao
public interface PhoneNumberDao {

    /**
     * Retrieve all phone numbers for the given user.
     */
    @Query("SELECT * FROM phone_numbers WHERE userId = :userId")
    List<PhoneNumber> getNumbersForUser(int userId);

    /**
     * Insert a new phone number.
     */
    @Insert
    void insertNumber(PhoneNumber phoneNumber);

    /**
     * Delete an existing phone number.
     */
    @Delete
    void deleteNumber(PhoneNumber phoneNumber);
}