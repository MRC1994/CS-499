package com.example.eventtrackingapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Ignore;

/**
 * Room entity representing an Event.
 * Stores title, description, datetime, expand state, and user association.
 */
@Entity(tableName = "events")
public class Event {

    @PrimaryKey(autoGenerate = true)
    private int id;               // Unique event ID (auto-generated)

    private String title;         // Event title
    private String description;   // Event description (optional)
    private String dateTime;      // Combined date and time as M/d/yyyy HH:mm
    private boolean expanded;     // Used for UI expand/collapse state
    private int userId;           // ID of the user who owns this event

    /**
     * Primary constructor used by Room.
     * @param title Title of the event
     * @param description Description text
     * @param dateTime Date and time string
     */
    public Event(String title, String description, String dateTime) {
        this.title = title;
        this.description = description;
        this.dateTime = dateTime;
        this.expanded = false;
    }

    /**
     * Convenience constructor to set userId directly.
     * Ignored by Room for instantiation.
     */
    @Ignore
    public Event(String title, String description, String dateTime, int userId) {
        this(title, description, dateTime);
        this.userId = userId;
    }

    // Getters and setters for Room and app usage
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDateTime() { return dateTime; }
    public void setDateTime(String dateTime) { this.dateTime = dateTime; }

    public boolean isExpanded() { return expanded; }
    public void setExpanded(boolean expanded) { this.expanded = expanded; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
}