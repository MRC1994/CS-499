package com.example.eventtrackingapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Room entity representing a phone number associated with a user.
 */
@Entity(tableName = "phone_numbers")
public class PhoneNumber {

    @PrimaryKey(autoGenerate = true)
    private int id;       // Unique ID for this phone number

    private String number; // The phone number string
    private int userId;    // ID of the user who owns this number

    public PhoneNumber(String number, int userId) {
        this.number = number;
        this.userId = userId;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNumber() { return number; }
    public void setNumber(String number) { this.number = number; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
}