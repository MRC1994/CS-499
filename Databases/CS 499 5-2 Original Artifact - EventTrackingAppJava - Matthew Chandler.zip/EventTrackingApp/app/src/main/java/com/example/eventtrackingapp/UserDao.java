package com.example.eventtrackingapp;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

/**
 * Data Access Object for User entities.
 * Handles account creation and lookup.
 */
@Dao
public interface UserDao {

    /**
     * Insert a new user record.
     */
    @Insert
    void insertUser(User user);

    /**
     * Retrieve a user by username (for login).
     * @param username The username to search for
     * @return User object or null if not found
     */
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User getUserByUsername(String username);
}