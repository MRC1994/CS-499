package com.example.eventtrackingapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Room entity representing a user account.
 */
@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    public int id;          // Unique user ID

    public String username; // Login username
    public String password; // Login password (stored in plain text for simplicity)

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
}