package com.example.eventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.Button;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityOptionsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * Main activity showing a scrollable list (grid) of events for the user.
 * Allows adding new events, adjusting settings, and logging out.
 */
public class EventGridActivity extends AppCompatActivity {

    private EventAdapter eventAdapter;
    private AppDatabase db;
    private int userId;

    /**
     * Initialize RecyclerView, buttons, and uniform text sizing.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_grid);

        // Get user ID from Intent
        userId = getIntent().getIntExtra("user_id", -1);
        db = AppDatabase.getInstance(this);

        // Setup RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerViewEvents);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setPadding(0, 16, 0, 72);
        eventAdapter = new EventAdapter(this, db.eventDao().getEventsForUser(userId));
        recyclerView.setAdapter(eventAdapter);

        // Find buttons
        Button buttonAddEvent  = findViewById(R.id.buttonAddEvent);
        Button buttonSettings  = findViewById(R.id.buttonSettings);
        Button buttonLogout    = findViewById(R.id.buttonLogout);

        // Add Event button launches AddEventActivity
        buttonAddEvent.setOnClickListener(v -> {
            Intent i = new Intent(this, AddEventActivity.class);
            i.putExtra("user_id", userId);
            addEventLauncher.launch(i);
        });

        // Settings button opens SettingsActivity
        buttonSettings.setOnClickListener(v -> {
            Intent i = new Intent(this, SettingsActivity.class);
            i.putExtra("user_id", userId);
            startActivity(i);
        });

        // Logout button with confirmation dialog
        buttonLogout.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Confirm Log Out")
                    .setMessage("Are you sure you want to log out?")
                    .setPositiveButton("Log Out", (d, w) -> {
                        Intent i = new Intent(this, MainActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i, ActivityOptionsCompat.makeCustomAnimation(
                                this, android.R.anim.slide_in_left, android.R.anim.slide_out_right
                        ).toBundle());
                        finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        // Compute and broadcast uniform text size for Adapter buttons
        buttonAddEvent.post(() -> {
            float smallestSizePx = buttonAddEvent.getTextSize();
            buttonSettings.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallestSizePx);
            buttonLogout.setTextSize(TypedValue.COMPLEX_UNIT_PX, smallestSizePx);

            TextSizeUtil.uniformTextSizePx = smallestSizePx;
            eventAdapter.setUniformTextSizePx(smallestSizePx);
            eventAdapter.notifyDataSetChanged();
        });
    }

    // Launcher for AddEventActivity
    private final ActivityResultLauncher<Intent> addEventLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {});

    /**
     * Refresh the event list when returning to this activity.
     */
    @Override
    protected void onResume() {
        super.onResume();
        eventAdapter.setEvents(db.eventDao().getEventsForUser(userId));
    }
}