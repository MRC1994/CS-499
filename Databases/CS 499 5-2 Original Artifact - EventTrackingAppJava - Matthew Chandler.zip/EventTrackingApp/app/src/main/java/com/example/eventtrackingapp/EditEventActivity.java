package com.example.eventtrackingapp;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Activity for editing an existing Event.
 * Loads event data, allows updates, and reschedules SMS reminders.
 */
public class EditEventActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "AppPrefs";
    private static final String PREF_NOTIFICATION_OFFSET = "notification_offset_hours";

    // UI elements
    private EditText editTextTitle, editTextDescription;
    private Button buttonDate, buttonTime, buttonEdit;

    // Hold current selection
    private String selectedDate = "", selectedTime = "";
    private int eventId = -1;
    private AppDatabase db;

    /**
     * Initializes the activity, pre-populates fields from the Intent, and sets listeners.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        db = AppDatabase.getInstance(getApplicationContext());

        // Find UI components
        editTextTitle = findViewById(R.id.editTextEventTitle);
        editTextDescription = findViewById(R.id.editTextEventDescription);
        buttonDate = findViewById(R.id.buttonSelectDate);
        buttonTime = findViewById(R.id.buttonSelectTime);
        buttonEdit = findViewById(R.id.buttonEditEvent);

        // Load event details from Intent extras
        eventId = getIntent().getIntExtra("event_id", -1);
        String title = getIntent().getStringExtra("event_title");
        String desc = getIntent().getStringExtra("event_description");
        String dt = getIntent().getStringExtra("event_datetime");
        if (title != null) editTextTitle.setText(title);
        if (desc  != null) editTextDescription.setText(desc);
        if (dt != null && dt.contains(" ")) {
            String[] parts = dt.split(" ");
            if (parts.length == 2) {
                selectedDate = parts[0];
                selectedTime = parts[1];
                buttonDate.setText(selectedDate);
                buttonTime.setText(selectedTime);
            }
        }

        // Show pickers on click
        buttonDate.setOnClickListener(v -> showDatePicker());
        buttonTime.setOnClickListener(v -> showTimePicker());

        // Handle Edit button
        buttonEdit.setOnClickListener(v -> {
            String updatedTitle = editTextTitle.getText().toString().trim();
            String updatedDesc  = editTextDescription.getText().toString().trim();
            String updatedDT    = selectedDate + " " + selectedTime;

            // Validate inputs
            if (updatedTitle.isEmpty() || selectedDate.isEmpty() || selectedTime.isEmpty()) {
                Toast.makeText(this, "Please fill in all required fields.", Toast.LENGTH_LONG).show();
                return;
            }
            if (eventId != -1) {
                Event existing = db.eventDao().getEventById(eventId);
                if (existing != null) {
                    // Update fields
                    existing.setTitle(updatedTitle);
                    existing.setDescription(updatedDesc);
                    existing.setDateTime(updatedDT);
                    db.eventDao().updateEvent(existing);

                    // Cancel the old alarm if it exists
                    AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    Intent cancelIntent = new Intent(this, SmsAlarmReceiver.class);
                    PendingIntent oldPi = PendingIntent.getBroadcast(
                            this,
                            existing.getId(),
                            cancelIntent,
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                    );
                    if (oldPi != null) am.cancel(oldPi);

                    // Schedule new SMS reminder
                    scheduleSms(existing);

                    Toast.makeText(this, "Event updated!", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(this, "Error updating event.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * Shows a DatePicker for editing the event date.
     */
    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        new DatePickerDialog(this,
                (view, year, month, day) -> {
                    selectedDate = (month + 1) + "/" + day + "/" + year;
                    buttonDate.setText(selectedDate);
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    /**
     * Shows a TimePicker for editing the event time.
     */
    private void showTimePicker() {
        final Calendar c = Calendar.getInstance();
        new TimePickerDialog(this,
                (view, hourOfDay, minute) -> {
                    selectedTime = String.format("%02d:%02d", hourOfDay, minute);
                    buttonTime.setText(selectedTime);
                },
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                true
        ).show();
    }

    /**
     * (Re)Schedules an SMS reminder after editing the event.
     */
    private void scheduleSms(Event event) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int offset = prefs.getInt(PREF_NOTIFICATION_OFFSET, 24);
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("M/d/yyyy HH:mm", Locale.US);
            Date eventDate = sdf.parse(event.getDateTime());
            long eventTimeMs = eventDate.getTime();
            long now = System.currentTimeMillis();
            if (eventTimeMs <= now) return;  // Skip past events

            long triggerAt = eventTimeMs - offset * 3600000L;
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, SmsAlarmReceiver.class);
            intent.putExtra("event_id", event.getId());
            PendingIntent pi = PendingIntent.getBroadcast(
                    this,
                    event.getId(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}