package com.example.eventtrackingapp;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

/**
 * Room database definition for Events and PhoneNumbers.
 * Uses a singleton pattern to provide a single instance.
 */
@Database(entities = {Event.class, PhoneNumber.class}, version = 3, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // Volatile singleton instance
    private static volatile AppDatabase instance;

    // DAO getters
    public abstract EventDao eventDao();
    public abstract PhoneNumberDao phoneNumberDao();

    /**
     * Returns the singleton AppDatabase instance.
     * Uses double-checked locking for thread safety.
     */
    public static AppDatabase getInstance(Context context) {
        if (instance == null) {
            synchronized (AppDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    "event_database")
                            .fallbackToDestructiveMigration()
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return instance;
    }
}